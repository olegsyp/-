-- ============================================================================
-- База данных информационной системы бронирования туров в туристическом агентстве
-- Стандартный DDL-скрипт (PostgreSQL / ANSI SQL) для импорта в Visual Paradigm:
-- Tools -> DB -> Reverse Database... -> DDL
-- ============================================================================

CREATE TABLE position (
    ID_position   SERIAL PRIMARY KEY,
    Title         VARCHAR(100)   NOT NULL,
    Salary        NUMERIC(12, 2) NOT NULL CHECK (Salary >= 0),
    Comment       TEXT
);
COMMENT ON TABLE position IS 'Должность';

CREATE TABLE employee (
    ID_employee   SERIAL PRIMARY KEY,
    FCs           VARCHAR(150) NOT NULL,
    Phone_number  VARCHAR(30)  NOT NULL,
    Mail          VARCHAR(120),
    ID_position   INTEGER      NOT NULL REFERENCES position(ID_position) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE employee IS 'Сотрудник';

CREATE TABLE tour_operator (
    ID_operator      SERIAL PRIMARY KEY,
    Company_name     VARCHAR(150) NOT NULL,
    Registry_number  VARCHAR(40)  NOT NULL UNIQUE,
    Phone_number     VARCHAR(30)  NOT NULL,
    Contact_email    VARCHAR(120)
);
COMMENT ON TABLE tour_operator IS 'Туроператор';

CREATE TABLE tour (
    ID_tour          SERIAL PRIMARY KEY,
    Title            VARCHAR(180)   NOT NULL,
    Country          VARCHAR(80)    NOT NULL,
    Hotel_name       VARCHAR(150)   NOT NULL,
    Departure_date   DATE           NOT NULL,
    Duration_days    INTEGER        NOT NULL CHECK (Duration_days > 0),
    Base_price       NUMERIC(12, 2) NOT NULL CHECK (Base_price >= 0),
    Available_slots  INTEGER        NOT NULL CHECK (Available_slots >= 0),
    ID_operator      INTEGER        NOT NULL REFERENCES tour_operator(ID_operator) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE tour IS 'Тур';

CREATE TABLE client (
    ID_client             SERIAL PRIMARY KEY,
    FCs                   VARCHAR(150) NOT NULL,
    Passport_data         VARCHAR(60)  NOT NULL UNIQUE,
    Phone_number          VARCHAR(30)  NOT NULL,
    Mail                  VARCHAR(120),
    Date_of_registration  DATE         NOT NULL DEFAULT CURRENT_DATE
);
COMMENT ON TABLE client IS 'Клиент';

CREATE TABLE booking (
    ID_booking      SERIAL PRIMARY KEY,
    Booking_date    TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Tourists_count  INTEGER        NOT NULL CHECK (Tourists_count > 0),
    Total_cost      NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (Total_cost >= 0),
    Status          VARCHAR(40)    NOT NULL DEFAULT 'Ожидает оплаты',
    Visa_needed     BOOLEAN        NOT NULL DEFAULT FALSE,
    ID_client       INTEGER        NOT NULL REFERENCES client(ID_client)     ON UPDATE CASCADE ON DELETE RESTRICT,
    ID_tour         INTEGER        NOT NULL REFERENCES tour(ID_tour)         ON UPDATE CASCADE ON DELETE RESTRICT,
    ID_employee     INTEGER        NOT NULL REFERENCES employee(ID_employee) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE booking IS 'Бронирование';

CREATE TABLE payment (
    ID_payment      SERIAL PRIMARY KEY,
    Payment_date    TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Amount          NUMERIC(12, 2) NOT NULL CHECK (Amount > 0),
    Payment_method  VARCHAR(40)    NOT NULL,
    Payment_type    VARCHAR(40)    NOT NULL,
    Receipt_number  VARCHAR(50)    NOT NULL UNIQUE,
    ID_booking      INTEGER        NOT NULL REFERENCES booking(ID_booking)   ON UPDATE CASCADE ON DELETE RESTRICT,
    ID_employee     INTEGER        NOT NULL REFERENCES employee(ID_employee) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE payment IS 'Платёж';
