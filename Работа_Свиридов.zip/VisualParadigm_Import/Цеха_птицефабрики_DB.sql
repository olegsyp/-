-- ============================================================================
-- База данных ИС «Цеха птицефабрики»
-- Стандартный DDL-скрипт (PostgreSQL / ANSI SQL) для импорта в Visual Paradigm:
-- Tools -> DB -> Reverse Database... -> DDL
-- ============================================================================

CREATE TABLE workshop (
    ID_workshop       SERIAL PRIMARY KEY,
    Title             VARCHAR(120) NOT NULL,
    Workshop_type     VARCHAR(60)  NOT NULL,
    Capacity          INTEGER      NOT NULL CHECK (Capacity > 0),
    Temperature_mode  VARCHAR(50)  NOT NULL
);
COMMENT ON TABLE workshop IS 'Цех';

CREATE TABLE position (
    ID_position       SERIAL PRIMARY KEY,
    Title             VARCHAR(100) NOT NULL,
    Comment           TEXT,
    Salary            NUMERIC(12, 2) NOT NULL CHECK (Salary >= 0)
);
COMMENT ON TABLE position IS 'Должность';

CREATE TABLE employee (
    ID_employee       SERIAL PRIMARY KEY,
    FCs               VARCHAR(150) NOT NULL,
    Phone_number      VARCHAR(30)  NOT NULL,
    Mail              VARCHAR(120),
    ID_position       INTEGER NOT NULL REFERENCES position(ID_position) ON UPDATE CASCADE ON DELETE RESTRICT,
    ID_workshop       INTEGER NOT NULL REFERENCES workshop(ID_workshop) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE employee IS 'Сотрудник';

CREATE TABLE batch (
    ID_batch          SERIAL PRIMARY KEY,
    Breed             VARCHAR(100) NOT NULL,
    Head_count        INTEGER      NOT NULL CHECK (Head_count >= 0),
    Start_date        DATE         NOT NULL,
    Status            VARCHAR(60)  NOT NULL,
    ID_workshop       INTEGER NOT NULL REFERENCES workshop(ID_workshop) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE batch IS 'Партия';

CREATE TABLE vet_control (
    ID_vet_control    SERIAL PRIMARY KEY,
    Check_date        DATE         NOT NULL,
    Conclusion        VARCHAR(150) NOT NULL,
    Vaccination       VARCHAR(150),
    ID_batch          INTEGER NOT NULL REFERENCES batch(ID_batch)       ON UPDATE CASCADE ON DELETE CASCADE,
    ID_employee       INTEGER NOT NULL REFERENCES employee(ID_employee) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE vet_control IS 'Ветеринарный контроль';

CREATE TABLE feeding_log (
    ID_feeding        SERIAL PRIMARY KEY,
    Log_date          DATE          NOT NULL,
    Feed_type         VARCHAR(100)  NOT NULL,
    Feed_consumption  NUMERIC(10,2) NOT NULL CHECK (Feed_consumption >= 0),
    Loss_count        INTEGER       NOT NULL DEFAULT 0 CHECK (Loss_count >= 0),
    ID_batch          INTEGER NOT NULL REFERENCES batch(ID_batch)       ON UPDATE CASCADE ON DELETE CASCADE,
    ID_employee       INTEGER NOT NULL REFERENCES employee(ID_employee) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE feeding_log IS 'Журнал кормления';

CREATE TABLE product (
    ID_product        SERIAL PRIMARY KEY,
    Product_name      VARCHAR(120) NOT NULL,
    Category          VARCHAR(80)  NOT NULL,
    Quantity          INTEGER      NOT NULL CHECK (Quantity >= 0),
    Release_date      DATE         NOT NULL,
    ID_batch          INTEGER NOT NULL REFERENCES batch(ID_batch)       ON UPDATE CASCADE ON DELETE RESTRICT,
    ID_workshop       INTEGER NOT NULL REFERENCES workshop(ID_workshop) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE product IS 'Продукция';
