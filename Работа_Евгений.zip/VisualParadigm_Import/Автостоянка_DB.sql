-- ============================================================================
-- База данных информационной системы «Автостоянка»
-- Стандартный DDL-скрипт (PostgreSQL / ANSI SQL) для импорта в Visual Paradigm:
-- Tools -> DB -> Reverse Database... -> DDL
-- ============================================================================

CREATE TABLE position (
    ID_position   SERIAL PRIMARY KEY,
    Title         VARCHAR(100) NOT NULL,
    Salary        NUMERIC(12, 2) NOT NULL CHECK (Salary >= 0),
    Comment       TEXT
);
COMMENT ON TABLE position IS 'Должность';

CREATE TABLE employee (
    ID_employee   SERIAL PRIMARY KEY,
    FCs           VARCHAR(150) NOT NULL,
    Phone_number  VARCHAR(30)  NOT NULL,
    Mail          VARCHAR(120),
    ID_position   INTEGER NOT NULL REFERENCES position(ID_position) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE employee IS 'Сотрудник';

CREATE TABLE client (
    ID_client             SERIAL PRIMARY KEY,
    FCs                   VARCHAR(150) NOT NULL,
    Phone_number          VARCHAR(30)  NOT NULL,
    Date_of_registration  DATE         NOT NULL DEFAULT CURRENT_DATE
);
COMMENT ON TABLE client IS 'Клиент';

CREATE TABLE vehicle (
    ID_vehicle     SERIAL PRIMARY KEY,
    License_plate  VARCHAR(20)  NOT NULL UNIQUE,
    Brand_model    VARCHAR(100) NOT NULL,
    Category       VARCHAR(50)  NOT NULL,
    ID_client      INTEGER NOT NULL REFERENCES client(ID_client) ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE vehicle IS 'Транспортное средство';

CREATE TABLE parking_spot (
    ID_spot      SERIAL PRIMARY KEY,
    Spot_number  VARCHAR(20)    NOT NULL UNIQUE,
    Zone         VARCHAR(60)    NOT NULL,
    Hourly_rate  NUMERIC(10, 2) NOT NULL CHECK (Hourly_rate >= 0),
    Status       VARCHAR(30)    NOT NULL DEFAULT 'Свободно'
);
COMMENT ON TABLE parking_spot IS 'Парковочное место';

CREATE TABLE subscription (
    ID_subscription  SERIAL PRIMARY KEY,
    Card_number      VARCHAR(40)    NOT NULL UNIQUE,
    Activation_date  DATE           NOT NULL,
    Completion_date  DATE           NOT NULL,
    Cost             NUMERIC(10, 2) NOT NULL CHECK (Cost >= 0),
    ID_client        INTEGER NOT NULL REFERENCES client(ID_client)     ON UPDATE CASCADE ON DELETE RESTRICT,
    ID_spot          INTEGER NOT NULL REFERENCES parking_spot(ID_spot) ON UPDATE CASCADE ON DELETE RESTRICT,
    CHECK (Completion_date >= Activation_date)
);
COMMENT ON TABLE subscription IS 'Абонемент';

CREATE TABLE parking_session (
    ID_session      SERIAL PRIMARY KEY,
    Entry_time      TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Exit_time       TIMESTAMP,
    Total_cost      NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (Total_cost >= 0),
    Payment_method  VARCHAR(40)    NOT NULL,
    Status          VARCHAR(30)    NOT NULL DEFAULT 'Активна',
    ID_vehicle      INTEGER NOT NULL REFERENCES vehicle(ID_vehicle)   ON UPDATE CASCADE ON DELETE RESTRICT,
    ID_spot         INTEGER NOT NULL REFERENCES parking_spot(ID_spot) ON UPDATE CASCADE ON DELETE RESTRICT,
    ID_employee     INTEGER NOT NULL REFERENCES employee(ID_employee) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE parking_session IS 'Парковочная сессия';
