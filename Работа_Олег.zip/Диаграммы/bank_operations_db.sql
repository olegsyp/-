-- ============================================================================
-- База данных информационной системы «Управление банковскими операциями»
-- Стандартный DDL-скрипт (PostgreSQL / ANSI SQL) для импорта в Visual Paradigm:
-- Tools -> DB -> Reverse Database... -> DDL
-- ============================================================================

CREATE TABLE position (
    ID_position   SERIAL PRIMARY KEY,
    Title         VARCHAR(100) NOT NULL,
    Access_level  VARCHAR(30)  NOT NULL,
    Comment       VARCHAR(255)
);
COMMENT ON TABLE position IS 'Должность сотрудника банка';

CREATE TABLE employee (
    ID_employee   SERIAL PRIMARY KEY,
    FIO           VARCHAR(150) NOT NULL,
    Phone_number  VARCHAR(20)  NOT NULL,
    Email         VARCHAR(100),
    ID_position   INTEGER NOT NULL REFERENCES position(ID_position) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE employee IS 'Сотрудник отделения';

CREATE TABLE client (
    ID_client             SERIAL PRIMARY KEY,
    FIO                   VARCHAR(150) NOT NULL,
    Passport_data         VARCHAR(30)  NOT NULL UNIQUE,
    Phone_number          VARCHAR(20)  NOT NULL,
    Birth_date            DATE         NOT NULL,
    Registration_date     DATE         NOT NULL DEFAULT CURRENT_DATE
);
COMMENT ON TABLE client IS 'Клиент банка';

CREATE TABLE account (
    ID_account      SERIAL PRIMARY KEY,
    Account_number  VARCHAR(20)    NOT NULL UNIQUE,
    Account_type    VARCHAR(40)    NOT NULL,
    Balance         NUMERIC(15, 2) NOT NULL DEFAULT 0.00 CHECK (Balance >= 0),
    Currency        VARCHAR(10)    NOT NULL DEFAULT 'RUB',
    Open_date       DATE           NOT NULL DEFAULT CURRENT_DATE,
    Status          VARCHAR(20)    NOT NULL DEFAULT 'Активен',
    ID_client       INTEGER NOT NULL REFERENCES client(ID_client) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE account IS 'Банковский счёт';

CREATE TABLE operation (
    ID_operation    SERIAL PRIMARY KEY,
    Operation_type  VARCHAR(50)    NOT NULL,
    Amount          NUMERIC(15, 2) NOT NULL CHECK (Amount > 0),
    Operation_date  TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    Status          VARCHAR(25)    NOT NULL DEFAULT 'Успешно',
    ID_account      INTEGER NOT NULL REFERENCES account(ID_account)   ON UPDATE CASCADE ON DELETE RESTRICT,
    ID_employee     INTEGER NOT NULL REFERENCES employee(ID_employee) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE operation IS 'Банковская операция';

CREATE TABLE credit_contract (
    ID_credit      SERIAL PRIMARY KEY,
    Loan_amount    NUMERIC(15, 2) NOT NULL CHECK (Loan_amount > 0),
    Interest_rate  NUMERIC(5, 2)  NOT NULL CHECK (Interest_rate > 0),
    Term_months    INTEGER        NOT NULL CHECK (Term_months > 0),
    Start_date     DATE           NOT NULL DEFAULT CURRENT_DATE,
    Status         VARCHAR(25)    NOT NULL DEFAULT 'Действует',
    ID_client      INTEGER NOT NULL REFERENCES client(ID_client)     ON UPDATE CASCADE ON DELETE RESTRICT,
    ID_employee    INTEGER NOT NULL REFERENCES employee(ID_employee) ON UPDATE CASCADE ON DELETE RESTRICT
);
COMMENT ON TABLE credit_contract IS 'Кредитный договор';

CREATE TABLE bank_card (
    ID_card          SERIAL PRIMARY KEY,
    Card_number      VARCHAR(20) NOT NULL UNIQUE,
    Card_type        VARCHAR(30) NOT NULL,
    Expiration_date  DATE        NOT NULL,
    Status           VARCHAR(25) NOT NULL DEFAULT 'Активна',
    ID_account       INTEGER NOT NULL REFERENCES account(ID_account) ON UPDATE CASCADE ON DELETE CASCADE
);
COMMENT ON TABLE bank_card IS 'Банковская карта';
